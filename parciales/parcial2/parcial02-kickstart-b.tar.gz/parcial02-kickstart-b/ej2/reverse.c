#include "reverse.h"
#include <stdio.h>

/**
 * @brief Devuelve en UNA NUEVA lista el resultado de invertir
 * el orden de los elementos de `l`
 *
 */
list reverse(list l) {

    //
    // COMPLETAR!!
    //

}
