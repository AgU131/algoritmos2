#ifndef _REVERSE_H
#define _REVERSE_H

#include "list.h"

/**
 * @brief Devuelve en UNA NUEVA lista el resultado de invertir
 * el orden de los elementos de `l`
 *
 */
list reverse(list l);

#endif
